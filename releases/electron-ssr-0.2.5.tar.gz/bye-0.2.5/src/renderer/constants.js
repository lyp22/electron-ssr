// 功能页面是否已读
export const STORE_KEY_FEATURE = 'view.feature'
// 是否自动下载ssr
export const STORE_KEY_AUTO_DOWNLOAD = 'ssr.autoDownload'
// ssr methods
export const STORE_KEY_SSR_METHODS = 'ssr.methods'
// ssr protocols
export const STORE_KEY_SSR_PROTOCOLS = 'ssr.protocols'
// ssr obfses
export const STORE_KEY_SSR_OBFSES = 'ssr.obfses'
// ssr配置页面提示标语
export const STORE_KEY_SSR_TIP = 'ssr.tip'
